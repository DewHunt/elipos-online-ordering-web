<style type="text/css">
	.jumbotron { margin: 3px; text-align: center; border-radius: 0px }
	.success-msg { color: green; }
	.error-msg { color: red; }
</style>