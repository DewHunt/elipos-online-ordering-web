<div class="jumbotron">
	<?php if ($retrieve_status): ?>
		<h3 class="success-msg">Your payment has been complete..</h3>
	<?php else: ?>
		<h3 class="error-msg">Card payment are incomplete, please try again.</h3>
	<?php endif ?>
</div>
