<script>
	$(document).on('click','#cancel-transaction',function() {
		Swal.fire({
			title: 'Are you sure?',
			text: "You want to cancel this payment!",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes'
		}).then((result) => {
			if (result.isConfirmed) {
				Swal.fire('Canceled!','Your transaction has been canceled.','success');
				window.location.replace("<?= base_url('cardstream_gateway/close/'); ?>")
			}
		});
	});
</script>