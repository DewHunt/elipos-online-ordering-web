<style type="text/css">
	.sagepay-input-div { background: lightgray; padding: 10px; }
	.error-div { padding-top: 10px; display: none; }
	.alert { border-radius: 0px; }
	.error { color: red; }
</style>