<style>
    #content-wrap { margin-bottom: 12px; background: #ededed; }
    #content-block { text-align: center; }
    .waiting-content { display: inline-flex; justify-content: center; align-items: center; width: calc(100% - 0px); height: calc(100vh - 325px); text-align: center; border: 2px solid #008000; }
    .waiting-msg { padding: 10px; font-size: 22px; background: #008000; color: #ffffff; }
    .waiting-img { width: 200px; }
</style>